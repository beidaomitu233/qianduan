window.addEventListener('load',function(){

   //第一部分 ，显示两侧按钮
   let btnleft=this.document.querySelector('.btnlun')
   let btnleft2=this.document.querySelector('.btnlun2')


   

})